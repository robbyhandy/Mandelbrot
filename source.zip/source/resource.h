//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by quickman.rc
//
#define ID_LOG_NEXT                     8
#define ID_LOG_PREV                     9
#define ID_SLIDESHOW                    10
#define ID_ZOOM                         11
#define ID_CALCULATE                    12
#define ID_FULLSCREEN                   13
#define ID_LOG_IMAGE                    14
#define ID_HOME                         16
#define ID_SAVE_IMAGE                   20
#define IDD_MAN_DIALOG                  101
#define IDC_MAG                         106
#define IDI_MAN                         107
#define IDC_HAND_CLOSED                 109
#define IDC_HAND_OPEN                   110
#define IDC_RTZOOM                      111
#define IDC_STATUS                      1001
#define IDC_INFO                        1002
#define IDC_STATUS2                     1007
#define IDC_PRECISION                   1010
#define IDC_ITERS                       1019
#define IDC_ADJUST_ITERS                1020
#define IDC_PALETTE                     1027
#define IDC_RENDERING                   1028
#define IDC_ALGORITHM                   1029
#define IDC_THREADS                     1030
#define IDC_LOGFILE                     1031
#define IDC_PAN_RATE                    1047
#define IDC_ZOOM_RATE                   1048
#define IDC_THUMBNAIL_FRAME             1049
#define ID_HELP_BUTTON                  1052
#define IDC_PAL_TEXT                    1053
#define IDC_RENDERING_TXT               1054
#define IDC_ALGORITHM_TEXT              1055
#define IDC_ASPECT                      1058
#define IDC_PNG                         1063
#define IDC_MAGS                        1064
#define IDC_SAVE_XSIZE                  1068
#define IDC_SAVE_YSIZE                  1069
#define IDC_IMAGEFILE                   1070
#define IDC_SAVEFILE                    1070

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1069
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
